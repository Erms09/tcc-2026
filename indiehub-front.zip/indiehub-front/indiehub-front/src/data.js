export const games = [
  {
    id: 1,
    title: "Neon Hollow",
    developer: "Pixel Forge",
    genre: "Ação",
    type: "2D",
    rating: 4.8,
    description: "Explore uma cidade neon tomada por criaturas e descubra o que aconteceu com seus habitantes.",
    colors: ["#6d28d9", "#ec4899"],
    steam: "https://store.steampowered.com/",
    github: "https://github.com/",
    discord: "https://discord.com/"
  },
  {
    id: 2,
    title: "Forestbound",
    developer: "Wild Byte",
    genre: "Aventura",
    type: "3D",
    rating: 4.6,
    description: "Uma aventura independente em uma floresta misteriosa cheia de segredos.",
    colors: ["#14532d", "#22c55e"],
    steam: "https://store.steampowered.com/",
    github: "https://github.com/",
    discord: "https://discord.com/"
  },
  {
    id: 3,
    title: "Starfall",
    developer: "Orbit Games",
    genre: "RPG",
    type: "2D",
    rating: 4.9,
    description: "Viaje por planetas desconhecidos e construa sua própria história entre as estrelas.",
    colors: ["#0f172a", "#2563eb"],
    steam: "https://store.steampowered.com/",
    github: "https://github.com/",
    discord: "https://discord.com/"
  },
  {
    id: 4,
    title: "Dead Signal",
    developer: "Night Owl Studio",
    genre: "Terror",
    type: "3D",
    rating: 4.5,
    description: "Um sinal misterioso leva você a uma estação abandonada onde nada é o que parece.",
    colors: ["#18181b", "#dc2626"],
    steam: "https://store.steampowered.com/",
    github: "https://github.com/",
    discord: "https://discord.com/"
  },
  {
    id: 5,
    title: "Tiny Kingdom",
    developer: "Mango Dev",
    genre: "Estratégia",
    type: "2D",
    rating: 4.4,
    description: "Construa seu pequeno reino, administre recursos e enfrente desafios.",
    colors: ["#92400e", "#f59e0b"],
    steam: "https://store.steampowered.com/",
    github: "https://github.com/",
    discord: "https://discord.com/"
  },
  {
    id: 6,
    title: "Driftline",
    developer: "Turbo Cat",
    genre: "Corrida",
    type: "3D",
    rating: 4.7,
    description: "Corridas rápidas, pistas estilizadas e muita liberdade para personalizar seu carro.",
    colors: ["#164e63", "#06b6d4"],
    steam: "https://store.steampowered.com/",
    github: "https://github.com/",
    discord: "https://discord.com/"
  }
];

export const genres = ["Todos", "Ação", "Aventura", "RPG", "Terror", "Estratégia", "Corrida"];
export const types = ["Todos", "2D", "3D"];