import React, { useMemo, useState } from "react";
import { Routes, Route, Link, NavLink, useParams, useNavigate } from "react-router-dom";
import { games, genres, types } from "./data";

function Header() {
  return (
    <header className="header">
      <Link to="/" className="brand">
        <span className="brand-mark">◆</span>
        <span>Indie<span>Hub</span></span>
      </Link>

      <nav className="nav">
        <NavLink to="/" end>Catálogo</NavLink>
        <NavLink to="/sobre">Sobre</NavLink>
        <NavLink to="/desenvolvedor">Sou desenvolvedor</NavLink>
      </nav>

      <Link to="/desenvolvedor" className="header-button">Cadastrar jogo</Link>
    </header>
  );
}

function GameCover({ game, large = false }) {
  return (
    <div
      className={`game-cover ${large ? "large" : ""}`}
      style={{ background: `linear-gradient(135deg, ${game.colors[0]}, ${game.colors[1]})` }}
    >
      <span className="cover-shape shape-one" />
      <span className="cover-shape shape-two" />
      <div className="cover-content">
        <small>INDIE</small>
        <strong>{game.title}</strong>
        <em>{game.genre}</em>
      </div>
    </div>
  );
}

function GameCard({ game }) {
  return (
    <Link to={`/jogo/${game.id}`} className="game-card">
      <GameCover game={game} />
      <div className="game-card-body">
        <div className="game-title-row">
          <h3>{game.title}</h3>
          <span className="rating">★ {game.rating}</span>
        </div>
        <p>{game.developer}</p>
        <div className="tags">
          <span>{game.genre}</span>
          <span>{game.type}</span>
        </div>
      </div>
    </Link>
  );
}

function Catalog() {
  const [search, setSearch] = useState("");
  const [genre, setGenre] = useState("Todos");
  const [type, setType] = useState("Todos");

  const filteredGames = useMemo(() => {
    return games.filter((game) => {
      const matchesSearch =
        game.title.toLowerCase().includes(search.toLowerCase()) ||
        game.developer.toLowerCase().includes(search.toLowerCase());
      const matchesGenre = genre === "Todos" || game.genre === genre;
      const matchesType = type === "Todos" || game.type === type;
      return matchesSearch && matchesGenre && matchesType;
    });
  }, [search, genre, type]);

  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">CATÁLOGO DE JOGOS INDEPENDENTES</span>
          <h1>Descubra o próximo<br /><span>grande indie.</span></h1>
          <p>
            Um espaço para jogadores encontrarem projetos independentes
            e para desenvolvedores ganharem visibilidade.
          </p>
          <a href="#catalogo" className="primary-button">Explorar jogos ↓</a>
        </div>
        <div className="hero-art">
          <div className="floating-card card-a">🎮<b>Projetos<br />indies</b></div>
          <div className="floating-card card-b">★ <b>Feedback<br />da comunidade</b></div>
          <div className="hero-orb">INDIE<br /><span>HUB</span></div>
        </div>
      </section>

      <main className="container" id="catalogo">
        <section className="section-heading">
          <div>
            <span className="eyebrow">VITRINE</span>
            <h2>Jogos em destaque</h2>
            <p>Encontre projetos independentes e conheça seus criadores.</p>
          </div>
          <span className="result-count">{filteredGames.length} jogos</span>
        </section>

        <section className="filters">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="🔎  Buscar jogo ou desenvolvedor..."
          />
          <select value={genre} onChange={(e) => setGenre(e.target.value)}>
            {genres.map((item) => <option key={item}>{item}</option>)}
          </select>
          <select value={type} onChange={(e) => setType(e.target.value)}>
            {types.map((item) => <option key={item}>{item}</option>)}
          </select>
        </section>

        {filteredGames.length ? (
          <div className="game-grid">
            {filteredGames.map((game) => <GameCard key={game.id} game={game} />)}
          </div>
        ) : (
          <div className="empty-state">Nenhum jogo encontrado com esses filtros.</div>
        )}
      </main>
    </>
  );
}

function GameDetails() {
  const { id } = useParams();
  const game = games.find((item) => item.id === Number(id));
  const [comment, setComment] = useState("");
  const [comments, setComments] = useState([
    { name: "Lucas", text: "A proposta do jogo é muito boa!" },
    { name: "Ana", text: "Gostei bastante do visual." }
  ]);

  if (!game) return <NotFound />;

  function addComment(e) {
    e.preventDefault();
    if (!comment.trim()) return;
    setComments([...comments, { name: "Você", text: comment.trim() }]);
    setComment("");
  }

  return (
    <main className="container detail-page">
      <Link to="/" className="back-link">← Voltar para o catálogo</Link>

      <section className="detail-hero">
        <GameCover game={game} large />
        <div className="detail-info">
          <span className="eyebrow">{game.genre} • {game.type}</span>
          <h1>{game.title}</h1>
          <p className="developer-name">por <strong>{game.developer}</strong></p>
          <div className="big-rating">★ {game.rating} <span>avaliação da comunidade</span></div>
          <p>{game.description}</p>
          <div className="external-links">
            <a href={game.steam} target="_blank" rel="noreferrer">Steam ↗</a>
            <a href={game.github} target="_blank" rel="noreferrer">GitHub ↗</a>
            <a href={game.discord} target="_blank" rel="noreferrer">Discord ↗</a>
          </div>
        </div>
      </section>

      <section className="feedback-section">
        <div>
          <span className="eyebrow">COMUNIDADE</span>
          <h2>Feedbacks</h2>
          <p>Ajude o desenvolvedor deixando sua opinião.</p>
        </div>
        <form className="comment-form" onSubmit={addComment}>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Escreva seu comentário..."
          />
          <button className="primary-button" type="submit">Enviar feedback</button>
        </form>
        <div className="comments">
          {comments.map((item, index) => (
            <article className="comment" key={index}>
              <div className="avatar">{item.name[0]}</div>
              <div><strong>{item.name}</strong><p>{item.text}</p></div>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}

function Developer() {
  const [submitted, setSubmitted] = useState(false);

  return (
    <main className="container developer-page">
      <section className="page-intro">
        <span className="eyebrow">ÁREA DO DESENVOLVEDOR</span>
        <h1>Coloque seu jogo na vitrine.</h1>
        <p>Cadastre seu projeto e conecte jogadores às suas plataformas.</p>
      </section>

      <div className="developer-layout">
        <form className="dev-form" onSubmit={(e) => { e.preventDefault(); setSubmitted(true); }}>
          <label>Nome do jogo<input required placeholder="Ex.: Meu Jogo Indie" /></label>
          <label>Desenvolvedor<input required placeholder="Nome do estúdio ou dev" /></label>
          <label>Gênero
            <select required defaultValue="">
              <option value="" disabled>Selecione</option>
              {genres.slice(1).map((g) => <option key={g}>{g}</option>)}
            </select>
          </label>
          <label>Tipo
            <select required defaultValue="">
              <option value="" disabled>Selecione</option>
              {types.slice(1).map((t) => <option key={t}>{t}</option>)}
            </select>
          </label>
          <label>Descrição<textarea required placeholder="Conte um pouco sobre o jogo..." /></label>
          <label>Link da Steam<input type="url" placeholder="https://..." /></label>
          <label>Link do GitHub<input type="url" placeholder="https://..." /></label>
          <label>Link do Discord<input type="url" placeholder="https://..." /></label>
          <button className="primary-button" type="submit">Cadastrar jogo</button>
          {submitted && <div className="success">✓ Jogo cadastrado com sucesso! (modo demonstração)</div>}
        </form>

        <aside className="dev-card">
          <span className="status-dot" />
          <h3>Divulgação automatizada</h3>
          <p>
            O diferencial do projeto prevê uma IA integrada para publicar
            automaticamente os jogos cadastrados no Instagram.
          </p>
          <div className="automation-status">
            <span>IA de divulgação</span><b>Planejada</b>
          </div>
          <small>A integração real com Instagram/IA será implementada no back-end.</small>
        </aside>
      </div>
    </main>
  );
}

function About() {
  return (
    <main className="container simple-page">
      <span className="eyebrow">SOBRE O PROJETO</span>
      <h1>Um espaço para dar visibilidade aos jogos indies.</h1>
      <p>
        O IndieHub é uma plataforma web de catálogo criada para auxiliar
        desenvolvedores independentes na divulgação de seus jogos,
        conectando criadores e jogadores.
      </p>
      <div className="about-grid">
        <div><b>Vitrine</b><span>Exibição de jogos com informações do projeto.</span></div>
        <div><b>Feedback</b><span>Avaliações e comentários da comunidade.</span></div>
        <div><b>Filtros</b><span>Busca por gênero, tipo e categorias.</span></div>
        <div><b>Links externos</b><span>Acesso a Steam, GitHub e Discord.</span></div>
      </div>
    </main>
  );
}

function NotFound() {
  const navigate = useNavigate();
  return (
    <main className="container not-found">
      <h1>404</h1>
      <p>Essa página não existe.</p>
      <button className="primary-button" onClick={() => navigate("/")}>Voltar ao catálogo</button>
    </main>
  );
}

function Footer() {
  return (
    <footer>
      <div className="footer-inner">
        <div><strong>◆ IndieHub</strong><p>Catálogo de jogos independentes.</p></div>
        <p>Projeto acadêmico • Front-end em React</p>
      </div>
    </footer>
  );
}

export default function App() {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<Catalog />} />
        <Route path="/jogo/:id" element={<GameDetails />} />
        <Route path="/desenvolvedor" element={<Developer />} />
        <Route path="/sobre" element={<About />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
      <Footer />
    </>
  );
}