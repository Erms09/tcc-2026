import React, { useMemo, useState } from "react";
import { Routes, Route, Link, NavLink, useParams, useNavigate, useLocation } from "react-router-dom";
import { games, genres, types } from "./data";

function Header({ user, onLogout }) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="header">
      <Link to="/catalogo" className="brand">
        <span className="brand-mark">◆</span>
        <span>Indie<span>Hub</span></span>
      </Link>

      <nav className="nav">
        <NavLink to="/catalogo" end>Catálogo</NavLink>
        <NavLink to="/sobre">Sobre</NavLink>
        <NavLink to="/desenvolvedor">Sou desenvolvedor</NavLink>
      </nav>

      <div className="header-right">
        {user?.role === "desenvolvedor" && (
          <>
            <Link to="/desenvolvedor" className="header-button">Cadastrar jogo</Link>
            <Link to="/desenvolvedor" className="header-button-mobile" aria-label="Cadastrar jogo">+</Link>
          </>
        )}

        {user && (
          <div className="profile-menu">
            <button
              className="profile-avatar"
              onClick={() => setMenuOpen(!menuOpen)}
              type="button"
            >
              {user.name[0].toUpperCase()}
            </button>

            {menuOpen && (
              <div className="profile-dropdown">
                <div className="profile-dropdown-info">
                  <strong>{user.name}</strong>
                  <span>{user.email}</span>
                  <span className="profile-role-badge">
                    {user.role === "desenvolvedor" ? "Desenvolvedor" : "Jogador"}
                  </span>
                </div>
                <button className="profile-logout" onClick={onLogout} type="button">
                  Sair
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </header>
  );
}

function GameCover({ game, large = false }) {
  return (
    <div
      className={`game-cover ${large ? "large" : ""}`}
      style={{ background: `linear-gradient(135deg, ${game.colors[0]}, ${game.colors[1]})` }}
    >
      <span className="cover-shape shape-one" />
      <span className="cover-shape shape-two" />
      <div className="cover-content">
        <small>INDIE</small>
        <strong>{game.title}</strong>
        <em>{game.genre}</em>
      </div>
    </div>
  );
}

function GameCard({ game, isFavorite, onToggleFavorite, view }) {
  function handleFavoriteClick(e) {
    e.preventDefault();
    e.stopPropagation();
    onToggleFavorite(game.id);
  }

  return (
    <Link to={`/jogo/${game.id}`} className={`game-card ${view === "list" ? "game-card-list" : ""}`}>
      <div className="game-cover-wrap">
        <GameCover game={game} />
        {game.isNew && <span className="badge-new">Novo</span>}
        <button
          className={`favorite-btn ${isFavorite ? "active" : ""}`}
          onClick={handleFavoriteClick}
          type="button"
          aria-label="Favoritar jogo"
        >
          {isFavorite ? "♥" : "♡"}
        </button>
        <div className="hover-preview">
          <p>{game.description}</p>
          <span>{game.reviews} avaliações</span>
        </div>
      </div>
      <div className="game-card-body">
        <div className="game-title-row">
          <h3>{game.title}</h3>
          <span className="rating">★ {game.rating}</span>
        </div>
        <p>{game.developer}</p>
        <div className="tags">
          <span>{game.genre}</span>
          <span>{game.type}</span>
        </div>
      </div>
    </Link>
  );
}

function Catalog() {
  const [search, setSearch] = useState("");
  const [genre, setGenre] = useState("Todos");
  const [type, setType] = useState("Todos");
  const [view, setView] = useState("grid");
  const [favorites, setFavorites] = useState([]);

  function toggleFavorite(id) {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((f) => f !== id) : [...prev, id]
    );
  }

  const filteredGames = useMemo(() => {
    return games.filter((game) => {
      const matchesSearch =
        game.title.toLowerCase().includes(search.toLowerCase()) ||
        game.developer.toLowerCase().includes(search.toLowerCase());
      const matchesGenre = genre === "Todos" || game.genre === genre;
      const matchesType = type === "Todos" || game.type === type;
      return matchesSearch && matchesGenre && matchesType;
    });
  }, [search, genre, type]);

  const stats = useMemo(() => {
    const developersCount = new Set(games.map((g) => g.developer)).size;
    const reviewsCount = games.reduce((total, g) => total + g.reviews, 0);
    return { gamesCount: games.length, developersCount, reviewsCount };
  }, []);

  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">CATÁLOGO DE JOGOS INDEPENDENTES</span>
          <h1>Descubra o próximo<br /><span>grande indie.</span></h1>
          <p>
            Um espaço para jogadores encontrarem projetos independentes
            e para desenvolvedores ganharem visibilidade.
          </p>
          <a href="#catalogo" className="primary-button">Explorar jogos ↓</a>

          <div className="stats-bar">
            <span><strong>{stats.gamesCount}</strong> jogos</span>
            <span className="stats-dot">•</span>
            <span><strong>{stats.developersCount}</strong> desenvolvedores</span>
            <span className="stats-dot">•</span>
            <span><strong>{stats.reviewsCount}</strong> avaliações</span>
          </div>
        </div>
        <div className="hero-art">
          <div className="floating-card card-a">🎮<b>Projetos<br />indies</b></div>
          <div className="floating-card card-b">★ <b>Feedback<br />da comunidade</b></div>
          <div className="hero-orb">INDIE<br /><span>HUB</span></div>
        </div>
      </section>

      <main className="container" id="catalogo">
        <section className="section-heading">
          <div>
            <span className="eyebrow">VITRINE</span>
            <h2>Jogos em destaque</h2>
            <p>Encontre projetos independentes e conheça seus criadores.</p>
          </div>
          <div className="section-heading-right">
            <span className="result-count">{filteredGames.length} jogos</span>
            <div className="view-toggle">
              <button
                className={view === "grid" ? "active" : ""}
                onClick={() => setView("grid")}
                type="button"
                aria-label="Ver em grade"
              >
                ▦
              </button>
              <button
                className={view === "list" ? "active" : ""}
                onClick={() => setView("list")}
                type="button"
                aria-label="Ver em lista"
              >
                ☰
              </button>
            </div>
          </div>
        </section>

        <section className="filters">
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="🔎  Buscar jogo ou desenvolvedor..."
          />
          <select value={genre} onChange={(e) => setGenre(e.target.value)}>
            {genres.map((item) => <option key={item}>{item}</option>)}
          </select>
          <select value={type} onChange={(e) => setType(e.target.value)}>
            {types.map((item) => <option key={item}>{item}</option>)}
          </select>
        </section>

        {filteredGames.length ? (
          <div className={view === "list" ? "game-list" : "game-grid"}>
            {filteredGames.map((game) => (
              <GameCard
                key={game.id}
                game={game}
                view={view}
                isFavorite={favorites.includes(game.id)}
                onToggleFavorite={toggleFavorite}
              />
            ))}
          </div>
        ) : (
          <div className="empty-state">Nenhum jogo encontrado com esses filtros.</div>
        )}
      </main>
    </>
  );
}

function GameDetails() {
  const { id } = useParams();
  const game = games.find((item) => item.id === Number(id));
  const [comment, setComment] = useState("");
  const [commentError, setCommentError] = useState("");
  const [sending, setSending] = useState(false);
  const [comments, setComments] = useState([
    { name: "Lucas", text: "A proposta do jogo é muito boa!" },
    { name: "Ana", text: "Gostei bastante do visual." }
  ]);

  if (!game) return <NotFound />;

  function addComment(e) {
    e.preventDefault();
    if (comment.trim().length < 3) {
      setCommentError("Escreva pelo menos 3 caracteres antes de enviar.");
      return;
    }
    setCommentError("");
    setSending(true);
    setTimeout(() => {
      setComments([...comments, { name: "Você", text: comment.trim() }]);
      setComment("");
      setSending(false);
    }, 700);
  }

  return (
    <main className="container detail-page">
      <Link to="/" className="back-link">← Voltar para o catálogo</Link>

      <section className="detail-hero">
        <GameCover game={game} large />
        <div className="detail-info">
          <span className="eyebrow">{game.genre} • {game.type}</span>
          <h1>{game.title}</h1>
          <p className="developer-name">por <strong>{game.developer}</strong></p>
          <div className="big-rating">★ {game.rating} <span>avaliação da comunidade</span></div>
          <p>{game.description}</p>
          <div className="external-links">
            <a href={game.steam} target="_blank" rel="noreferrer">Steam ↗</a>
            <a href={game.github} target="_blank" rel="noreferrer">GitHub ↗</a>
            <a href={game.discord} target="_blank" rel="noreferrer">Discord ↗</a>
          </div>
        </div>
      </section>

      <section className="feedback-section">
        <div>
          <span className="eyebrow">COMUNIDADE</span>
          <h2>Feedbacks</h2>
          <p>Ajude o desenvolvedor deixando sua opinião.</p>
        </div>
        <form className="comment-form" onSubmit={addComment} noValidate>
          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Escreva seu comentário..."
            className={commentError ? "input-error" : ""}
          />
          {commentError && <span className="field-error">{commentError}</span>}
          <button className="primary-button" type="submit" disabled={sending}>
            {sending ? <span className="spinner" /> : "Enviar feedback"}
          </button>
        </form>
        <div className="comments">
          {comments.map((item, index) => (
            <article className="comment" key={index}>
              <div className="avatar">{item.name[0]}</div>
              <div><strong>{item.name}</strong><p>{item.text}</p></div>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}

function Developer() {
  const [form, setForm] = useState({
    title: "", dev: "", genre: "", type: "", description: "",
    steam: "", github: "", discord: ""
  });
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  function updateField(field, value) {
    setForm({ ...form, [field]: value });
  }

  function isValidUrl(value) {
    if (!value) return true;
    try {
      new URL(value);
      return true;
    } catch {
      return false;
    }
  }

  function validate() {
    const newErrors = {};
    if (form.title.trim().length < 2) newErrors.title = "Digite o nome do jogo.";
    if (form.dev.trim().length < 2) newErrors.dev = "Digite o nome do desenvolvedor.";
    if (!form.genre) newErrors.genre = "Selecione um gênero.";
    if (!form.type) newErrors.type = "Selecione um tipo.";
    if (form.description.trim().length < 10) newErrors.description = "Escreva pelo menos 10 caracteres na descrição.";
    if (!isValidUrl(form.steam)) newErrors.steam = "Link inválido. Use uma URL completa, ex.: https://...";
    if (!isValidUrl(form.github)) newErrors.github = "Link inválido. Use uma URL completa, ex.: https://...";
    if (!isValidUrl(form.discord)) newErrors.discord = "Link inválido. Use uma URL completa, ex.: https://...";
    return newErrors;
  }

  function handleSubmit(e) {
    e.preventDefault();
    const newErrors = validate();
    setErrors(newErrors);
    setSubmitted(false);
    if (Object.keys(newErrors).length > 0) return;

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
    }, 900);
  }

  return (
    <main className="container developer-page">
      <section className="page-intro">
        <span className="eyebrow">ÁREA DO DESENVOLVEDOR</span>
        <h1>Coloque seu jogo na vitrine.</h1>
        <p>Cadastre seu projeto e conecte jogadores às suas plataformas.</p>
      </section>

      <div className="developer-layout">
        <form className="dev-form" onSubmit={handleSubmit} noValidate>
          <label>Nome do jogo<span className="required-mark">*</span>
            <input
              placeholder="Ex.: Meu Jogo Indie"
              value={form.title}
              onChange={(e) => updateField("title", e.target.value)}
              className={errors.title ? "input-error" : ""}
            />
            {errors.title && <span className="field-error">{errors.title}</span>}
          </label>

          <label>Desenvolvedor<span className="required-mark">*</span>
            <input
              placeholder="Nome do estúdio ou dev"
              value={form.dev}
              onChange={(e) => updateField("dev", e.target.value)}
              className={errors.dev ? "input-error" : ""}
            />
            {errors.dev && <span className="field-error">{errors.dev}</span>}
          </label>

          <label>Gênero<span className="required-mark">*</span>
            <select
              value={form.genre}
              onChange={(e) => updateField("genre", e.target.value)}
              className={errors.genre ? "input-error" : ""}
            >
              <option value="" disabled>Selecione</option>
              {genres.slice(1).map((g) => <option key={g}>{g}</option>)}
            </select>
            {errors.genre && <span className="field-error">{errors.genre}</span>}
          </label>

          <label>Tipo<span className="required-mark">*</span>
            <select
              value={form.type}
              onChange={(e) => updateField("type", e.target.value)}
              className={errors.type ? "input-error" : ""}
            >
              <option value="" disabled>Selecione</option>
              {types.slice(1).map((t) => <option key={t}>{t}</option>)}
            </select>
            {errors.type && <span className="field-error">{errors.type}</span>}
          </label>

          <label>Descrição<span className="required-mark">*</span>
            <textarea
              placeholder="Conte um pouco sobre o jogo..."
              value={form.description}
              onChange={(e) => updateField("description", e.target.value)}
              className={errors.description ? "input-error" : ""}
            />
            {errors.description && <span className="field-error">{errors.description}</span>}
          </label>

          <label>Link da Steam
            <input
              type="url"
              placeholder="https://..."
              value={form.steam}
              onChange={(e) => updateField("steam", e.target.value)}
              className={errors.steam ? "input-error" : ""}
            />
            {errors.steam && <span className="field-error">{errors.steam}</span>}
          </label>

          <label>Link do GitHub
            <input
              type="url"
              placeholder="https://..."
              value={form.github}
              onChange={(e) => updateField("github", e.target.value)}
              className={errors.github ? "input-error" : ""}
            />
            {errors.github && <span className="field-error">{errors.github}</span>}
          </label>

          <label>Link do Discord
            <input
              type="url"
              placeholder="https://..."
              value={form.discord}
              onChange={(e) => updateField("discord", e.target.value)}
              className={errors.discord ? "input-error" : ""}
            />
            {errors.discord && <span className="field-error">{errors.discord}</span>}
          </label>

          <div className="form-actions">
            <button className="primary-button" type="submit" disabled={loading}>
              {loading ? <span className="spinner" /> : "Cadastrar jogo"}
            </button>
            <Link to="/catalogo" className="secondary-button">Cancelar</Link>
          </div>
          {submitted && <div className="success">✓ Jogo cadastrado com sucesso! (modo demonstração)</div>}
        </form>

        <aside className="dev-card">
          <span className="status-dot" />
          <h3>Divulgação automatizada</h3>
          <p>
            O diferencial do projeto prevê uma IA integrada para publicar
            automaticamente os jogos cadastrados no Instagram.
          </p>
          <div className="automation-status">
            <span>IA de divulgação</span><b>Planejada</b>
          </div>
          <small>A integração real com Instagram/IA será implementada no back-end.</small>
        </aside>
      </div>
    </main>
  );
}

function About() {
  return (
    <main className="container simple-page">
      <span className="eyebrow">SOBRE O PROJETO</span>
      <h1>Um espaço para dar visibilidade aos jogos indies.</h1>
      <p>
        O IndieHub é uma plataforma web de catálogo criada para auxiliar
        desenvolvedores independentes na divulgação de seus jogos,
        conectando criadores e jogadores.
      </p>
      <div className="about-grid">
        <div><b>Vitrine</b><span>Exibição de jogos com informações do projeto.</span></div>
        <div><b>Feedback</b><span>Avaliações e comentários da comunidade.</span></div>
        <div><b>Filtros</b><span>Busca por gênero, tipo e categorias.</span></div>
        <div><b>Links externos</b><span>Acesso a Steam, GitHub e Discord.</span></div>
      </div>
    </main>
  );
}

function Auth({ onLogin }) {
  const [tab, setTab] = useState("entrar");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("jogador");
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  function validate() {
    const newErrors = {};

    if (tab === "cadastro" && name.trim().length < 2) {
      newErrors.name = "Digite seu nome completo.";
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = "Digite um e-mail válido, ex.: voce@email.com.";
    }

    if (password.length < 6) {
      newErrors.password = "A senha precisa ter pelo menos 6 caracteres.";
    }

    return newErrors;
  }

  function handleSubmit(e) {
    e.preventDefault();
    const newErrors = validate();
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;

    setLoading(true);
    setTimeout(() => {
      onLogin({ name: tab === "entrar" ? email.split("@")[0] : name, email, role });
      setLoading(false);
      navigate("/catalogo");
    }, 900);
  }

  function switchTab(newTab) {
    setTab(newTab);
    setErrors({});
  }

  return (
    <main className="auth-page">
      <div className="auth-side">
        <div className="auth-orb">INDIE<br /><span>HUB</span></div>
        <h2>Bem-vindo de volta.<br /><span>Ou comece agora.</span></h2>
        <p>
          Entre para acompanhar seus jogos favoritos, ou crie uma conta
          para começar a explorar o catálogo indie.
        </p>
      </div>

      <div className="auth-card-wrap">
        <div className="auth-card">
          <div className="auth-brand">
            <span className="brand-mark">◆</span>
            <span>Indie<span>Hub</span></span>
          </div>

          <div className="auth-tabs">
            <button
              className={`auth-tab-btn ${tab === "entrar" ? "active" : ""}`}
              onClick={() => switchTab("entrar")}
              type="button"
            >
              Entrar
            </button>
            <button
              className={`auth-tab-btn ${tab === "cadastro" ? "active" : ""}`}
              onClick={() => switchTab("cadastro")}
              type="button"
            >
              Cadastrar
            </button>
          </div>

          <form className="auth-form" onSubmit={handleSubmit} noValidate>
            {tab === "cadastro" && (
              <label>Nome
                <input
                  placeholder="Seu nome"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={errors.name ? "input-error" : ""}
                />
                {errors.name && <span className="field-error">{errors.name}</span>}
              </label>
            )}

            <label>E-mail
              <input
                type="email"
                placeholder="voce@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={errors.email ? "input-error" : ""}
              />
              {errors.email && <span className="field-error">{errors.email}</span>}
            </label>

            <label>Senha
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className={errors.password ? "input-error" : ""}
              />
              {errors.password && <span className="field-error">{errors.password}</span>}
            </label>

            <div className="role-select">
              <span className="role-select-label">Entrar como:</span>
              <div className="role-options">
                <button
                  type="button"
                  className={`role-btn ${role === "jogador" ? "active" : ""}`}
                  onClick={() => setRole("jogador")}
                >
                  Jogador
                </button>
                <button
                  type="button"
                  className={`role-btn ${role === "desenvolvedor" ? "active" : ""}`}
                  onClick={() => setRole("desenvolvedor")}
                >
                  Desenvolvedor
                </button>
              </div>
            </div>

            <button className="primary-button auth-submit" type="submit" disabled={loading}>
              {loading ? (
                <span className="spinner" />
              ) : tab === "entrar" ? "Entrar" : "Criar conta"}
            </button>
          </form>
        </div>
      </div>
    </main>
  );
}

function NotFound() {
  const navigate = useNavigate();
  return (
    <main className="container not-found">
      <h1>404</h1>
      <p>Essa página não existe.</p>
      <button className="primary-button" onClick={() => navigate("/")}>Voltar ao catálogo</button>
    </main>
  );
}

export default function App() {
  const location = useLocation();
  const navigate = useNavigate();
  const isAuthScreen = location.pathname === "/";
  const [user, setUser] = useState(null);

  function handleLogout() {
    setUser(null);
    navigate("/");
  }

  return (
    <>
      {!isAuthScreen && <Header user={user} onLogout={handleLogout} />}
      <div className="page-fade" key={location.pathname}>
        <Routes>
          <Route path="/" element={<Auth onLogin={setUser} />} />
          <Route path="/catalogo" element={<Catalog />} />
          <Route path="/jogo/:id" element={<GameDetails />} />
          <Route path="/desenvolvedor" element={<Developer />} />
          <Route path="/sobre" element={<About />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </div>
    </>
  );
}