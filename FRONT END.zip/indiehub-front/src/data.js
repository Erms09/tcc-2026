export const games = [];

export const genres = ["Todos"];
export const types = ["Todos"];